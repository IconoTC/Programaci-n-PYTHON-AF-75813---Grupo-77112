''' Crear una excepcion personalizada  '''

# Version minima
#class NegativoError(Exception):
#    pass

class NegativoError(Exception):
    def __init__(self, msg) -> None:
        self.message = msg
        
    def getMessage(self):
        return self.message
    
    
try:
    edad = int(input("Introduce tu edad: "))
    if edad < 0:
        # lanzar la excepcion
        raise NegativoError("La edad no puede ser negativa")
except NegativoError as error:
    print(error.getMessage())