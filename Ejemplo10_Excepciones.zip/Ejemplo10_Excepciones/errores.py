# try-except-else-finally

try:
    # lineas de codigo que pueden generar errores
    numero1 = int(input("Introduce dividendo: "))
    numero2 = int(input("Introduce divisor: "))
    division = numero1 / numero2
except ValueError as ex:
    # Se ejecuta cuando ha ocurrido un error
    print("El valor introducido no es numerico")
    print(ex)
except ZeroDivisionError as error:
    print("No se puede dividir por cero")
    print(error)
except Exception as e:
    print("Ha ocurrido un error")
    print(e)
else:
    # Se ejecuta cuando no ha ocurrido ningun error
    print("Resultado:", division)
finally:
    # Siempre se ejecuta, haya error o no
    print("********* FIN ********") 
    
'''  Estructuras minimas '''
try:
    pass
finally:
    pass

try:
    pass
except:
    pass

''' Esto no lo interpreta 
try:
    pass
else:
    pass
'''