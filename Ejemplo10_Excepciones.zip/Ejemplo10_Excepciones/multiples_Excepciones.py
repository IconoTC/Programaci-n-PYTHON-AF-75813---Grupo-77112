datos = ['1', 'dos', '3', '4', '5']
suma = 0

for idx in range(len(datos) + 1):  # de 0 a 5
    try:
        # acceder al dato
        dato = datos[idx]
        
        # lo convertimos a numero
        numero = int(dato)
    except (ValueError, IndexError, Exception) as ex:
        print("Error de tipo:", type(ex))
        print("Mensaje de error:", ex)
    else:
        suma += numero
        
print("Suma:", suma)