texto = "bienvenidos al curso de Python"

print(texto.capitalize()) # solo la primera letra en mayuscula y el resto en minusculas
print(texto.title()) # mayuscula la primera letra de cada palabra
print(texto.upper()) # todo el texto en mayusculas
print(texto.lower()) # todo el texto en minusculas
print(texto.swapcase()) # intercambia mayusculas por minusculas y viceversa

print("isalnum", texto.isalnum()) #  solo letras y numeros False por los espacios en blanco
print("isalnum", "hola".isalnum()) # True
print("isalnum", "1234".isalnum()) # True
print("isalnum", "hola1234".isalnum()) # True

print("isalpha", texto.isalpha()) #  solo letras False por los espacios en blanco
print("isalpha", "hola".isalpha()) # True
print("isalpha", "1234".isalpha()) # False
print("isalpha", "hola1234".isalpha()) # False

print("isdigit", texto.isdigit()) #  solo digitos False por las letras y espacios en blanco
print("isdigit", "hola".isdigit()) # False
print("isdigit", "1234".isdigit()) # True
print("isdigit", "hola1234".isdigit()) # False

print("isupper", texto.isupper()) # solo mayusculas, ignora si hay numeros, espacios u otros caracteres  False
print("isupper", "HOLA".isupper()) # True
print("isupper", "HOLA1234".isupper()) # True
print("isupper", "HOLA 1234".isupper()) # True
print("isupper", "HOLA_1234".isupper()) # True

print("islower", texto.islower()) # Igual pero en minusculas False
print("islower", "hola".islower()) # True

print("Longitud:", len(texto))
print("Longitud:", texto.__len__()) # __ indica que es privado pero se puede acceder y funciona

# La tabla ASCII esta ordenada (1º numeros, 2º mayusculas, 3º minusculas)
print("max", max(texto)) # El caracter con mas valor dentro de la tabla ASCII   y
print("min", min(texto)) # el espacio en blanco

ejemplo = "     Hoy es lunes       "
print(ejemplo, end=".\n")
print("lstrip", ejemplo.lstrip(), end=".\n") # Elimina espacios por la izquierda
print("rstrip", ejemplo.rstrip(), end=".\n") # Elimina espacios por la derecha
print("strip", ejemplo.strip(), end=".\n") # Elimina espacios por la izquierda y la derecha

print("replace", texto.replace("e", "E")) # Reemplaza todas las letras e
print("replace", texto.replace("e", "E", 1)) # Solo reemplaza la primera letra e que encuentra

palabras = texto.split()  # Por defecto parte la cadena por el espacio en blanco
print(type(palabras)) # palabras es una lista (list)

# Los indices siempre empiezan desde 0
print("find", texto.find("o"))  # 9
print("find", texto.find("o", 10))  # 19 Empieza a buscar a partir del indice 10
print("find", texto.find("o", 10, 15)) # -1 Busca entre el indice 10 y el 15 sin incluirlo
print("rfind", texto.rfind("o")) # 28