# Operadores aritmeticos (+, -, *, /, %, **, //)
numero1 = 7
numero2 = 2
print("Suma:", numero1 + numero2)
print("Resta:", numero1 - numero2)
print("Multiplicacion:", numero1 * numero2)
print("Division:", numero1 / numero2)
print("Resto o modulo de la division:", numero1 % numero2)
print("Potencia:", numero1 ** numero2)
print("Division entera:", numero1 // numero2)

# Operadores de asignacion (+=, -=, *=, /=, %=, **=, //=)
numero1 += 5   # numero1 = numero1 + 5

# En Python no existen incrementos y decrementos
numero1 += 1    # numero1++
numero1 -= 1    # numero1--

# Operadores de comparacion (<,>,<=,>=,==,!=)
print("numero1 es menor que numero2", numero1 < numero2) # False
print("numero2 es igual a 2", numero2 == 2) # True
print("numero2 es distinto a 23", numero2 != 23) # True

# Operadores logicos (and, or, not)
print("and:", numero2 > 1 and numero2 == 2) # True porque ambas condiciones son ciertas
print("or:", numero2 > 1 or numero2 == 23) # True porque la primera condicion se cumple
print("not:", not(numero2 == 23)) # True
print("not:", not(numero2 == 2)) # False

# Operadores de identidad (is, is not)
# Sirven para verificar si es el mismo objeto
num1 = 6
num2 = 6
print("Es el mismo objeto", num1 is num2) # True

nombres1 = ["Juan", "Maria"]
nombres2 = ["Juan", "Maria"]
print("Es el mismo objeto", nombres1 is nombres2) # False porque las direcciones de memoria son distintas
print("No es el mismo objeto", nombres1 is not nombres2) # True
print(nombres1 == nombres2) # True las listas son iguales

# Operadores de pertenencia (in, not in)
print("Luis esta en nombres1:", "Luis" in nombres1) # False
print("Luis no esta en nombres1:", "Luis" not in nombres1) # True
print("Maria esta en nombres1:", "Maria" in nombres1)