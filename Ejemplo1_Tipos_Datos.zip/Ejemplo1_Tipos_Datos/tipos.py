'''
    Comentarios de Bloque (Docstring)
    3 comillas simples o dobles
    Ejemplo de tipos de datos en Python
'''

# numeros enteros (int)
numero1 = 8
numero2 = 4
suma = numero1 + numero2
print("Suma:", suma, ", Tipo:", type(suma))
# TypeError: can only concatenate str (not "int") to str
# print("suma:" + suma)
print("suma:" + str(suma))

# numeros reales (float)
base = 4.89
altura = 9.23
triangulo = base * altura / 2
print("Area del triangulo:", triangulo, ", Tipo:", type(triangulo))
# round(que_valor, num_decimales)
print("Area del triangulo:", round(triangulo, 2), ", Tipo:", type(triangulo))

# booleanos: True o False (bool)
soltero = True
print("Estas soltero?", soltero, ", Tipo:", type(soltero))

# Cadenas de texto (str)
# se puede utilizar comillas dobles o simples
nombre = "Juan"
apellido = 'Lopez'
print(nombre, apellido, ", Tipo:", type(nombre))
print(nombre, apellido, ", Tipo:", type(nombre), sep="")
print(nombre, apellido, ", Tipo:", type(nombre), sep="", end=".\n")