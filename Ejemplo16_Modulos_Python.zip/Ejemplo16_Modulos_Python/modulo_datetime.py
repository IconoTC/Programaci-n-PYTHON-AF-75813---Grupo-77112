# Este modulo contiene funciones para manejar fechas y horas

import datetime
import time

# Crear la fecha
hoy = datetime.date(2025,5,8)
print(hoy)

print("Año:", hoy.year)
print("Mes:", hoy.month)
print("Dia:", hoy.day)

# Formato personalizado
# Crear la fecha y hora
dt = datetime.datetime(2025,5,8, 13,32,25,10)
print(dt.date().strftime('%d/%m/%y'))
print(dt.time().strftime('%H:%M:%S'))

# A que dia de la semana corresponde empezando 0=lunes
print("Dia semana:", hoy.weekday())

# A que dia de la semana corresponde empezando 1=lunes
print("Dia semana:", hoy.isoweekday())

# Fecha de mañana
print("Mañana:", hoy.replace(day=9))
print(hoy) # No modifica la fecha

# Fecha y hora actual
print("Ahora:", datetime.datetime.now())

# Crear un perido de tiempo
periodo = datetime.timedelta(days=7, hours=6)
print(datetime.datetime.today() + periodo)

# Desde el modulo time podemos obtener la hora actual
print(time.ctime())