# conjuntos: colecciones sin orden (no tenemos indices)
# NO permite elementos duplicados, los ignora
# No se garantiza el orden de entrada de los elementos
# Se crean con {}
# IMPORTANTE: conjunto = {} lo interpreta como diccionario

frutas = {'manzana', 'naranja', 'pera', 'naranja', 'platano'}
print(type(frutas)) # <class 'set'>
print(frutas)
print(frutas)

# Conjunto vacio
conjunto = set()
print(type(conjunto)) # <class 'set'>
conjunto = {}
print(type(conjunto)) # <class 'dict'>

# agregar elementos al conjunto
frutas.add('fresas')
print(frutas)

# eliminar un elemento
frutas.remove('platano')
print(frutas)

# Para recorrer conjuntos solo por item
for item in frutas:
    print(item, end=" ")
print()

# Copiar un conjunto en otro
# copy() funciona con listas pero no con tuplas
otro = frutas.copy()
print(otro)

# Igual que en listas y tuplas funciona Operadores de pertenencia
print('manzana' in frutas) # True
print('melocoton' in frutas) # False

# Borrar todos los elementos
frutas.clear()
print(frutas)