# Ejemplo 1
# Con la palabra abracadabra crear un conjunto con las letras que no sean a,b,c
conjunto_letras = {letra for letra in 'abracadabra' if letra not in {'a','b','c'}}
print(conjunto_letras) # {'r', 'd'}


# Ejemplo 2
# crear un conjunto con las vocales unicas en palabras de mas de 6 letras
dias = ('lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo')
vocales = {letra  for dia in dias  for letra in dia if len(dia)>6 and letra in 'aeiou'}
print(vocales) # {'o', 'i', 'e'}


# Ejemplo 3
# Crear un conjunto de tuplas (letra, frecuencia) para las vocales de cada dia
dias = ('lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo')
vocales_frecuencia = { (dia, letra, dia.count(letra)) for dia in dias for letra in dia if letra in 'aeiou'}
print(vocales_frecuencia)