import sqlite3

# Abrir la conexion
conexion = sqlite3.connect("Ejemplo13_BBDD_Sqlite/tienda.db")

# Obtener un cursor
cursor = conexion.cursor()

''' *********************** Insert ******************** '''
#cursor.execute("insert into PRODUCTOS values (1, 'Pantalla', 129.95)")
#cursor.execute("insert into PRODUCTOS values (2, 'Scanner', 450.75)")

lista = [(3, 'Teclado', 29.95), (4, 'Raton', 18.90), (5, 'Impresora', 89.25), (6, 'Auriculares', 230)]
sql = "insert into PRODUCTOS values (?,?,?)"
#cursor.executemany(sql, lista)

''' *********************** Consultas ******************** '''
# consultar todos los productos
cursor.execute("select * from PRODUCTOS")
productos = cursor.fetchall() # recoger los resultados de la query
for prod in productos:
    print(prod)
print("---- FIN ----")

# consultar todos los productos con precio inferior a 50
cursor.execute("select * from PRODUCTOS where precio < 50")
productos = cursor.fetchall() 
for prod in productos:
    print(prod)
print("---- FIN ----")

# consultar todos los productos cuya descripcion sea Impresora
dato = input("Introduce la descripcion a buscar: ")
parametro = tuple([dato])
cursor.execute("select * from PRODUCTOS where descripcion = ?", parametro)
productos = cursor.fetchall() 
for prod in productos:
    print(prod)
print("---- FIN ----")

# consultar todos los productos ordenados por precio ascendente
cursor.execute("select * from PRODUCTOS ORDER by precio")
productos = cursor.fetchall() 
for prod in productos:
    print(prod)
print("---- FIN ----")

# consultar todos los productos ordenados por precio descendente
cursor.execute("select * from PRODUCTOS ORDER by precio DESC")
productos = cursor.fetchall() 
for prod in productos:
    print(prod)
print("---- FIN ----")

# consultar todos los productos comiencen por letra R
parametro = ('R%',) # Los parametros se tienen que pasar en tuplas
cursor.execute("select * from PRODUCTOS where descripcion LIKE ?", parametro)
productos = cursor.fetchall() 
for prod in productos:
    print(prod)
print("---- FIN ----")

# consultar todos los productos que contienen la letra e y el precio es inferior a 50
parametros = ('%e%', 50)
cursor.execute("select * from PRODUCTOS where descripcion LIKE ? and precio < ?", parametros)
productos = cursor.fetchall() 
for prod in productos:
    print(prod)
print("---- FIN ----")

''' *********************** Modificar ******************** '''
# subir un 10% el precio de la impresora
parametro = ('Impresora',)
cursor.execute('update PRODUCTOS set precio = precio * 1.1 where descripcion = ?', parametro)
conexion.commit()

# Cambiar la descripcion de raton a raton inalambrico
parametros = ('Raton inalambrico', 'Raton')
cursor.execute('update PRODUCTOS set descripcion = ? where descripcion = ?', parametros)
conexion.commit()

''' *********************** Eliminar ******************** '''
# Eliminar todos los Scanner
parametro = ('Scanner',)
cursor.execute("delete from PRODUCTOS where descripcion = ?", parametro)

# IMPORTANTE EL COMMIT
conexion.commit()

# Cerrar la BBDD
conexion.close()