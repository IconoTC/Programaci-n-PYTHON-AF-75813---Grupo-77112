print(1,2,3,4,5, sep=" - ", end=".\n")

def datos_trabajador(nombre, estadoCivil="Soltero", sueldo=24000):
    print(nombre, "esta", estadoCivil, "y gana", sueldo)
    
datos_trabajador("Maria")
datos_trabajador("Juan", 35000)
datos_trabajador(nombre="Juan", sueldo=35000)

'''
    En Python se pueden pasar los argumentos de 2 formas:
        - por posicion: datos_trabajador("Juan", 35000) entiende que 35000 es el estadoCivil
        - keywords: datos_trabajador(nombre="Juan", sueldo=35000)
'''

# Con keywords podemos cambiar el orden de los argumentos
datos_trabajador(sueldo=35000, nombre="Juan")
datos_trabajador(nombre="Pedro", estadoCivil="Casado")
datos_trabajador("Pedro", "Casado")


'''
    Ejercicio:
    Crear una funcion que reciba:
        - datos como numero variable de argumentos
        - separador que por defecto sera " | "
    y retorne los datos recibidos unidos por el separador en una cadena (metodo join)   
'''
def concatenar(*datos: str, separador=" | "):
    return separador.join(datos)

print(concatenar('1','2','3','4','5', separador=", "))
print(concatenar('1','2','3','4','5', separador=" - "))
print(concatenar('1','2','3','4','5'))