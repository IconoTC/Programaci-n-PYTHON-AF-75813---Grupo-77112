'''
    Crear una funcion que recibe un texto y retorna:
        - el texto en mayusculas
        - el texto en minusculas
        - la longitud del texto
'''

def procesar_texto(texto: str):
    mayusculas = texto.upper()
    minusculas = texto.lower()
    longitud = len(texto)
    return mayusculas, minusculas, longitud


# recuperar con multiples variables
txtMay, txtMin, txtLen = procesar_texto("Buenos dias")
print(txtMay)
print(txtMin)
print(txtLen)

# recuperar con una coleccion del tipo tupla
tupla = procesar_texto("Buenos dias")
for dato in tupla:
    print(dato)