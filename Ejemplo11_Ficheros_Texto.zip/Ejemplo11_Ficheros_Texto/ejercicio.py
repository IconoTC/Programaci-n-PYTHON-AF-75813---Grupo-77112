'''
    leer la informacion del fichero.txt y generar una copia.txt (w+t)
    mostrar el contenido de copia.txt
'''

import sys

sys.stdout.reconfigure(encoding="utf-8")

# Abrir el fichero en modo lectura
fichero_lectura = open("Ejemplo11_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# Abrir el fichero en modo lectura y escritura
fichero_escritura = open("Ejemplo11_Ficheros_Texto/copia.txt", "w+t", encoding="utf-8")

# leer el contenido del fichero en una lista
contenido = fichero_lectura.readlines() 

# escribimos el contenido en el fichero de copia.txt
for linea in contenido:
    fichero_escritura.write(linea)
    
# leer copia.txt
fichero_escritura.seek(0)
for linea in fichero_escritura.readlines():
    print(linea, end="")
    
# cerrar ambos ficheros
fichero_lectura.close()
fichero_escritura.close()