nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']

for item in nombres:
    print(item, end=" ")
print()

''' rangos '''
# range(inicio, final, salto)  el numero final no esta incluido
# Mostrar los numeros del 0 al 9
for numero in range(10):   # Rango va desde 0 hasta num-1
    print(numero, end=" ")
print()

# Mostrar los numeros del 1 al 10
for numero in range(1, 11):   # Rango va desde 1 hasta fin-1
    print(numero, end=" ")
print()

# Mostrar los numeros del 0 al 10 de 2 en 2
for numero in range(0, 11, 2):   # Rango va desde 0 hasta fin-1
    print(numero, end=" ")
print()

# Mostrar los numeros del 10 al 1 decreciente
for numero in range(10, 0, -1):   # Rango va desde 1 hasta fin-1
    print(numero, end=" ")
print()

# Mostrar los numeros del 10 al 0 decreciente de 2 en 2
for numero in range(10, -1, -2):   # Rango va desde 1 hasta fin-1
    print(numero, end=" ")
print()

# Mostrar los elementos de la lista de nombres por posicion
for idx in range(len(nombres)): # Rango de 0 a 4
    print(nombres[idx], end=" ")
print()
