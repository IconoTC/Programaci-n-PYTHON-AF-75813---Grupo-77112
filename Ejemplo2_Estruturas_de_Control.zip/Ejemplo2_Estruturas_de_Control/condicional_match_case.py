'''
    El usuario introduce una letra (l,m,x,j,v,s,d)
    Mostrar el dia de la semana correspondiente
    o "Dia no valido" si no es correcto
    Puede ser que la letra se introduzca en minuscula o mayuscula
    Ideas: or, upper(), lower(), in
'''

letra = input("Introduce una letra (l,m,x,j,v,s,d): ")

match letra.upper():
    case 'L':
        print("Es lunes")
    case 'M':
        print("Es martes")
    case 'X':
        print("Es miercoles")
    case 'J':
        print("Es jueves")
    case 'V':
        print("Es viernes")
    case 'S':
        print("Es sabado")
    case 'D':
        print("Es Domingo")
    case _:   # Actua como default
        print("Dia no valido")