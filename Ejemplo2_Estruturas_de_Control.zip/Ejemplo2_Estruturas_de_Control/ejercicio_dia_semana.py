'''
    El usuario introduce una letra (l,m,x,j,v,s,d)
    Mostrar el dia de la semana correspondiente
    o "Dia no valido" si no es correcto
    Puede ser que la letra se introduzca en minuscula o mayuscula
    Ideas: or, upper(), lower(), in
'''

letra = input("Introduce una letra (l,m,x,j,v,s,d): ")

if letra == 'l' or letra == 'L':
    print("Es lunes")
elif letra.upper() == 'M':
    print("Es martes")
elif letra.lower() == 'x':
    print("Es miercoles")
elif letra in ['j', 'J']:
    print("Es jueves")
elif letra.upper() == 'V':
    print("Es viernes")
elif letra.lower() == 's':
    print("Es sabado")
elif letra.lower() == 'd':
    print("Es Domingo")
else:
    print("Dia no valido")