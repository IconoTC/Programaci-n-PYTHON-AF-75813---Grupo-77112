# la funcion map, se aplica sobre una coleccion donde
# con cada elemento se invoca a otra funcion que lo modifica
# o devuelve un  nuevo elemento
# Importante que la funcion retorne un elemento
# sintaxis: map(funcion, coleccion)

# Ejemplo 1
numeros = [3,8,5,14,28]

def duplicar(numero):
    return numero*2

numeros_dobles = list(map(duplicar, numeros))
print(numeros) # la coleccion original no se modifica
print(numeros_dobles)


# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)

def subir_punto(item):
    return item[0], item[1]+1

nuevas_notas = dict(map(subir_punto, alumnos.items()))
print(nuevas_notas)


# Ejemplo 3
class Persona:
    def __init__(self, nombre, edad) -> None:
        self.nombre = nombre
        self.edad = edad

    def __str__(self) -> str:
        return "Me llamo {} y tengo {} años".format(self.nombre, self.edad)

personas = [Persona("Juan",27), Persona("Maria",15), Persona("Pedro",21)]

def modificar_persona(persona: Persona):
    persona.nombre = persona.nombre.upper()
    persona.edad += 1
    return persona

personas = list(map(modificar_persona, personas))
for p in personas:
    print(p)