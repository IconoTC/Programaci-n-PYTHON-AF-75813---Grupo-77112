class Persona:
    
    # constructor o inicializador
    def __init__(self, nombre, edad) -> None:
        #pass   # significa que el cuerpo esta vacio
        # self.nombre y self.edad son atributos o propiedades o campos de la instancia de Persona
        self.nombre = nombre
        self.edad = edad
    
    # cuando un metodo recibe (self) hace que sea un metodo de instancia 
    def mostrarInfo(self):
        #print("Me llamo", self.nombre, "y tengo", self.edad, "años")
        print("Me llamo {} y tengo {} años".format(self.nombre, self.edad))
    
 
# crear objetos o instancias de Persona
p1 = Persona("Juan", 23) # En p1 guardamos la direccion de memoria del objeto que acabamos de crear
p2 = Persona("Maria", 42)

# Mostrar el objeto
print(p1) # <__main__.Persona object at 0x107411fd0>
p1.mostrarInfo()

# Los atributos o propiedades son publicas
p1.edad += 1
p1.mostrarInfo()
p2.mostrarInfo()