class Direccion:
    def __init__(self, calle: str, numero: int, poblacion: str) -> None:
        self.calle = calle
        self.numero = numero
        self.poblacion = poblacion
     
    # sobreescribirmos el metodo __str__ heredado de la clase Object    
    def __str__(self) -> str:
        # Mayor, 5 (Madrid)
        return "{}, {} ({})".format(self.calle, self.numero, self.poblacion)

class Persona:
    def __init__(self, nombre: str, edad: int, direccion: Direccion) -> None:
        self.nombre = nombre
        self.edad = edad
        self.direccion = direccion

    def mostrarInfo(self):
        print("Me llamo {}, tengo {} años y vivo en {}".format(self.nombre, self.edad, self.direccion))
              
dirJuan = Direccion("Mayor", 5, "Madrid")
p1 = Persona("Juan", 23, dirJuan)
p1.mostrarInfo()

p2 = Persona("Maria", 42, Direccion("Diagonal", 123, "Barcelona"))
p2.mostrarInfo()

# Los atributos o propiedades son publicas
p1.edad += 1

# Cambiar la direccion de Juan a Castellana, 61, Madrid
p1.direccion.calle = "Castellana"
p1.direccion.numero = 61
p1.mostrarInfo()