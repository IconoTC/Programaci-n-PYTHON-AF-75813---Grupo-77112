class FechaPublica:
    def __init__(self, dia, mes, anyo) -> None:
        self.dia = dia
        self.mes = mes
        self.anyo = anyo
        
    def __str__(self) -> str:
        return "{}/{}/{}".format(self.dia, self.mes, self.anyo)
    
hoy = FechaPublica(6,5,2025)
print(hoy)
erronea = FechaPublica(98,1234,-56)
print(erronea)

# Una clase encapsulada define todas sus propiedades como privadas
# y se accede a ellas a través de los métodos get y set publicos
class Fecha:
    def __init__(self, dia, mes, anyo) -> None:
        self.setDia(dia)
        self.setMes(mes)
        self.setAnyo(anyo)
        
    def getDia(self):
        return self.__dia
    
    def setDia(self, dia):
        # los dias son validos del 1 al 31
        if dia > 0 and dia <= 31:
            # creamos la propiedad privada
            self.__dia = dia
        else:
            self.__dia = 0
            
    def getMes(self):
        return self.__mes
    
    def setMes(self, mes):
        if mes >= 1 and mes <= 12:
            self.__mes = mes
        else:
            self.__mes = 0
            
    def getAnyo(self):
        return self.__anyo
    
    def setAnyo(self, anyo):
        # los años validos son 2025 y 2026
        if anyo == 2025 or anyo == 2026:
            self.__anyo = anyo
        else:
            self.__anyo = 0
        
    def __str__(self) -> str:
        return "{}/{}/{}".format(self.__dia, self.__mes, self.__anyo)
    
hoy = Fecha(6,5,2025)
print(hoy)
erronea = Fecha(98,1234,-56)
print(erronea)