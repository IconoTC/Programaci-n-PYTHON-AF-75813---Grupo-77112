# Ejemplo 1
# se trata de crear otra lista con la longitud de cada palabra
lista_palabras = ["casa", "tunel", "manzana", "ayuntamiento"]
longitud_palabras = []

for palabra in lista_palabras:
    longitud_palabras.append(len(palabra))
print(longitud_palabras)

''' compresion de listas '''
longitud_palabras = [len(palabra) for palabra in lista_palabras]
print(longitud_palabras)

# Ejemplo 2
# crear una lista con los numeros pares del 0 al 10 (range)
num_pares = [num for num in range(0,11,2)]
print(num_pares)

num_pares = [num for num in range(0,11) if num % 2 == 0]
print(num_pares)

# Ejemplo 3
# Crear otra matriz solo con los numeros impares
# [[1,3], [5], [7,9] ]
matriz = [[1,2,3], [4,5,6], [7,8,9] ]
numeros_impares = [[num for num in fila if num % 2 != 0] for fila in matriz]
print(numeros_impares)