# listas: colecciones ordenadas de elementos (tienen indice)
# en todas las colecciones los elementos pueden ser de diferente tipo
# permite elementos duplicados
# se crean []

list1 = ['Maria', 'Perez', 30, 'soltera', 'sin hijos']
list2 = ['estudiante', 'medicina', 28010]
print(list1)
print(list2)

# Copiar una lista en otra
otra = list1.copy()

# crear una lista vacia
lista_vacia = []
lista = list()

# unir listas
lista = list1 + list2 # el orden es importante
print(lista)
lista = list2 + list1
print(lista)

# longitud de la lista
print("Longitud:", len(lista))
print("Longitud:", lista.__len__())

# Acceso a los elementos de la lista
# indice en positivo comienza por el primero, por la izquierda
# empiezas a contar por 0
print(lista[2])
# indice en negativo comienza por el ultimo, por la derecha
# empiezas a contar por -1
print(lista[-2])  # 8 -2 = 6

# Agregar elementos al final -> append
lista.append("morena")
print(lista)

# Agregar elementos en una determinada posicion -> insert
lista.insert(0, 1.70)
print(lista)

# Agregar varios elementos a la vez -> extend
lista.extend([1,2,3]) # los elementos tienen que ir en una coleccion
print(lista)

# Eliminar elementos por posicion
del lista[0]  # elimina el primer elemento
print(lista)

# Eliminar por elemento, el primero que encuentra
lista.remove(3) # elimina el primer elemento 3 que encuentra
print(lista)

# Buscar un elemento y me retorna el indice donde se encuentra
indice = lista.index('Perez')
print(indice)

# Mostrar cuantas soltera hoy
print("Cuantas soltera?", lista.count("soltera"))

# Invertir la lista
print(lista)
lista.reverse()
print(lista)

# Ordenar listas
colores = ['rojo', 'verde', 'azul', 'amarillo']
print(sorted(colores))  # La muestra ordenada pero no la modifica
print(colores)
# Ordena en forma descendente
print(sorted(colores, reverse=True)) 

# Establecer el orden, p.e. longitud de cada elemento
print(sorted(colores, key=lambda dato: len(dato)))

# Eliminar todos los elementos de la lista
colores.clear()
print(colores)

''' slices [begin:stop:step] '''
# mostrar todos los elementos de la lista
print("Todos:", lista[:])

# mostrar  los ultimos 4 elementos de la lista
print("Ultimos 4:", lista[-4:])

# Mostrar los elementos del indice 3 al 6
print("Del 3 al 6:", lista[3:7]) # recordar que el ultimo no esta incluido, como los rangos

# Mostrar los elementos del indice 6 al 3
print("Del 6 al 3:", lista[6:2:]) # la lista sale vacia
print("Del 6 al 3:", lista[6:2:-1])

# mostrar todos los elementos de la lista en orden inverso
print("Todos inverso:", lista[::-1])

# mostrar todos los elementos de la lista en orden inverso de 2 en 2
print("Todos inverso:", lista[::-2])