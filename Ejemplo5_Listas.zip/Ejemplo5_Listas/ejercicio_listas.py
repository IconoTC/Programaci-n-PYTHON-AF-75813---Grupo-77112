# crear una lista llamada coles con rojo, verde y azul

# mostrar el tipo de la variable colores

# mostrar el contenido de la lista

# recorrer la lista con for in

# recorrer la lista a traves del indice con range

# mostrar el color verde por posicion

# borrar el color azul con del

# borrar el color azul con remove

# crear una lista vacia mas_coles

# en la nueva lista concatenar colores con : [blanco, negro, rosa, azul]

# añadir el color naranja al final

# añadir el color marron al principio

# mostrar la longitud de la lista

''' slices '''
# mostrar los 2 ultimos elementos

# mostrar del ultimo al antepenultimo

# mostrar los primeros 5 elementos

# mostrar del indice 2 al 4

# mostrar del 0 al penultimo de 2 en 2

# mostrar desde el penultimo al primero de 2 en 2