# crear una lista llamada coles con rojo, verde y azul
colores = ["rojo", "verde", "azul"]

# mostrar el tipo de la variable colores
print(type(colores)) # <class 'list'>

# mostrar el contenido de la lista
print(colores)

# recorrer la lista con for in
for color in colores:
    print(color, end=" ")
print()

# recorrer la lista a traves del indice con range
for idx in range(len(colores)):
    print(colores[idx], end=" ")
print()

# mostrar el color verde por posicion
print(colores[1])

# borrar el color azul con del
#del colores[2]
#print(colores)

# borrar el color azul con remove
colores.remove("azul")
print(colores)

# crear una lista vacia mas_colores
mas_colores = []
mas_colores = list()

# en la nueva lista concatenar colores con : [blanco, negro, rosa, azul]
mas_colores = colores + ["blanco", "negro", "rosa", "azul"]
print(mas_colores)

# añadir el color naranja al final
mas_colores.append("naranja")
print(mas_colores)

# añadir el color marron al principio
mas_colores.insert(0, "marron")
print(mas_colores)

# mostrar la longitud de la lista
print(len(mas_colores))
print(mas_colores.__len__())

''' slices [start:end:step]'''
# mostrar los 2 ultimos elementos
print(mas_colores[-2:])

# mostrar del ultimo al antepenultimo
print(mas_colores[-1:-4:-1])

# mostrar los primeros 5 elementos
print(mas_colores[:5])

# mostrar del indice 2 al 4
print(mas_colores[2:5])

# mostrar del 0 al penultimo de 2 en 2
print(mas_colores[0:-1:2])

# mostrar desde el penultimo al primero de 2 en 2
print(mas_colores[-2::-2])