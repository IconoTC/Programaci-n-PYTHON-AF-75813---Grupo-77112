# tuplas: Colecciones ordenadas (con indice) pero inmutables
# se permiten elementos duplicados
# se crean con ()
# Ejemplos: dias de la semana, meses del año, estado civil, puntos cardinales, ....

# tuplas de varias dimensiones tambien funcionan
# slices funcionan igual que las listas
# operadores de pertenencia: in y not in

dias = ('lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo')
print(type(dias)) # <class 'tuple'>
print(dias)

# crear tupla vacia
tupla_vacia = ()
tupla_vacia = tuple()

# Recorrer la tupla por item
for item in dias:
    print(item, end=" ")
print()

# Recorrer la tupla por indice
for idx in range(len(dias)):
    print(dias[idx], end=" ")
print()

# Intento borrar el lunes 
# TypeError: 'tuple' object doesn't support item deletion
# del dias[0]

# Concatenar tuplas en otra tupla
numeros = (1,2,3,4,5)
otra_tupla = dias + numeros
print(otra_tupla)

# Para concatenar tuplas, la tupla ha de tener mas de un elemento
# TypeError: can only concatenate tuple (not "str") to tuple
# mas_dias = dias + ("sabado")
# mas_dias = dias + ("sabado", "domingo") Funciona
mas_dias = dias + ("sabado",) # le engañamos al interprete para que piense que hay mas de un elemento
print(mas_dias)

# Longitud de la tupla
print(len(mas_dias))
print(mas_dias.__len__())

# Cuantos sabados hay
print("Sabados:", mas_dias.count("sabado"))

# En que posicion esta el viernes
print("Posicion del viernes:", mas_dias.index("viernes"))

# Otra forma de crear tuplas
tupla = 1,2,3,4,5
print(type(tupla)) # <class 'tuple'>

# Tambien se puede hacer con listas, multiplicar tuplas
resultado = tupla * 2
print(resultado) # (1, 2, 3, 4, 5, 1, 2, 3, 4, 5)

# Convertir una tupla en lista
lista_dias = list(mas_dias)
print(type(lista_dias)) # <class 'list'>

# Convertir una lista en tupla
nueva_tupla = tuple(lista_dias)
print(type(nueva_tupla)) # <class 'tuple'>

# Tambien funciona con listas
print("Minimo:", min(tupla))
print("Maximo:", max(tupla))
print("Suma:", sum(tupla))